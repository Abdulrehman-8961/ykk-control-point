<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class ImportSampleTests implements ToCollection, WithStartRow
{
    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            if ($row[0] == 'Test Name' || empty($row[0])) continue;

            $testName       = trim($row[0]);
            $testDateRaw       = trim($row[1]);
            $woNumber       = trim($row[2]);
            $assetNo        = trim($row[3]);
            $bosubi         = trim($row[4]);
            $productionDateRaw = trim($row[5]);
            $lot            = trim($row[6]);

$testDate = is_numeric($testDateRaw)
    ? Date::excelToDateTimeObject($testDateRaw)->format('Y-m-d')
    : date('Y-m-d', strtotime($testDateRaw));

$productionDate = is_numeric($productionDateRaw)
    ? Date::excelToDateTimeObject($productionDateRaw)->format('Y-m-d')
    : date('Y-m-d', strtotime($productionDateRaw));

            $samples = array_slice($row->toArray(), 7);
            $samples = array_filter($samples, fn($s) => $s !== null);
            $totalSamples = count($samples);
            if ($totalSamples === 0) continue;

            $min = min($samples);
            $max = max($samples);
            $avg = array_sum($samples) / $totalSamples;
            $avg_minus = round($avg - $min, 2);
            $avg_plus  = round($max - $avg, 2);

            // Fetch definitions
            $testDefinition = DB::table('test_definitions')->where('test_name', $testName)->where('status', 1)->where('is_deleted', 0)->first();
            if (!$testDefinition) continue;

            $workorder = DB::table('workorders')->where('workorder_no', $woNumber)->where('status', 1)->where('is_deleted', 0)->first();
            if (!$workorder) continue;

            $asset = DB::table('assets')->where('asset_no', $assetNo)->where('status', 1)->where('is_deleted', 0)->first();
            if (!$asset) continue;

            $itemcode = DB::table('itemcodes')->where('item_code', $workorder->itemcode_id)->where('status', 1)->where('is_deleted', 0)->first();
            $itemCategoryId = DB::table('item_categories_itemcodes')->where('itemcode_id', $itemcode->id)->where('is_deleted', 0)->first();
            $itemCategory = DB::table('item_categories')->where('id', $itemCategoryId->item_category_id)->where('status', 1)->where('is_deleted', 0)->first();

            $thresholdId = DB::table('test_thresholds')->where('test_name_id', $testDefinition->id)->where('status', 1)->where('is_deleted', 0)->first();

            $thresholds = DB::table('test_threshold_item_categories')
                ->where('test_threshold_id', $thresholdId->id)
                ->where('item_category_id', $itemCategory->id)
                ->where('is_deleted', 0)
                ->first();  

            $standardValue = $testDefinition->standard === 'YFS' ? $thresholds->YFS : ($testDefinition->standard === 'YFGS' ? $thresholds->YFGS : null);
            $safetyThreshold = $thresholds->safety_threshold;
            $absorptionValue = $thresholds->absorption;
            if (!empty($absorptionValue)){
                $safetyThreshold = 'MAX ABSORB %';
                $standardValue = $absorptionValue;
            }

$stdva_value = null;

if ($testDefinition->test_type === 'Perf-Str') {
    $sumSqDiff = array_sum(array_map(fn($s) => pow($s - $avg, 2), $samples));
    $stdDev = sqrt($sumSqDiff / ($totalSamples - 1));

    // Apply conditional rounding based on criteria
    if ($testDefinition->criteria === 'Min') {
        $stdva_value = round($stdDev); // round to whole number
    } elseif ($testDefinition->criteria === 'Max') {
        $stdva_value = round($stdDev, 2); // round to 2 decimals
    } else {
        $stdva_value = round($stdDev, 2); // fallback (default)
    }
}


            $results = ['min' => null, 'avg' => null, 'max' => null];
            $sampleResults = [];
            $sampleCounter = 1;

            foreach ($samples as $sample) {
                $sample_result = 'fail';

                if ($testDefinition->test_type === 'Dimension') {
                    $sample_result = ($sample >= $thresholds->min && $sample <= $thresholds->max) ? 'pass' : 'fail';

                } elseif ($testDefinition->test_type === 'Perf-Str') {
                    if ($testDefinition->criteria === 'Min') {
                        if ($sample < $standardValue) {
                            $sample_result = 'fail';
                        } elseif ($sample >= $standardValue && $sample <= ($standardValue + $safetyThreshold)) {
                            $sample_result = 'warning';
                        } elseif ($sample > ($standardValue + $safetyThreshold)) {
                            $sample_result = 'pass';
                        }
                    } elseif ($testDefinition->criteria === 'Max') {
                        $sample_result = ($sample <= $standardValue) ? 'pass' : 'fail';
                    }
                } elseif ($testDefinition->test_type === 'Perf-Weight') {
                    $sample_result = ($sample <= $absorptionValue) ? 'pass' : 'fail';
                }

                $sampleResults[] = [
                    'sample_number' => $sampleCounter,
                    'sample_value'  => $sample,
                    'sample_result' => $sample_result
                ];

                $sampleCounter++;
            }


            $results['min'] = $sampleResults[array_search($min, $samples)]['sample_result'];
            $results['avg'] = $sampleResults[array_search(round($avg, 2), array_map('round', $samples))]['sample_result'] ?? 'pass';
            $results['max'] = $sampleResults[array_search($max, $samples)]['sample_result'];

            // Insert sample_tests
            $sampleTestId = DB::table('sample_tests')->insertGetId([
                'test_name_id' => $testDefinition->id,
                'workorder_id' => $workorder->id,
                'item_category' => $itemCategory->item_category,
                'itemcode' => $workorder->itemcode_id,
                'itemcode_desc' => $itemcode->description ?? '',
                'color' => $workorder->itemcode_color_id,
                'length' => $workorder->length,
                'asset_id' => $asset->id,
                'bosubi' => $bosubi,
                'lot' => $lot,
                'production_date' => $productionDate,
                'sample_date' => $testDate,
                'sample_number' => $totalSamples,
                'min' => $min,
                'min_result' => $results['min'],
                'avg' => round($avg, 2),
                'avg_result' => $results['avg'],
                'max' => $max,
                'max_result' => $results['max'],
                'avg_minus' => $avg_minus,
                'avg_plus' => $avg_plus,
                'stdva_value' => $stdva_value,
                'standard_value' => $standardValue,
                'safety_threshold' => $safetyThreshold,
                'test_standard' => $testDefinition->standard,
                'absorption_value' => $absorptionValue,
                'status'       => 1,
                'created_by'   => Auth::id(),
                'updated_by'   => Auth::id(),
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);

    DB::table('sample_tests_audit_trail')->insert([
        'user_id'           => Auth::id(),
        'description'       => 'QC Test imported successfully',
        'sample_test_id'    => $sampleTestId,
        'created_at'        => now()
    ]);            

            // Insert sample_tests_samples
            foreach ($sampleResults as $sampleRow) {
                DB::table('sample_tests_samples')->insert([
                    'sample_test_id' => $sampleTestId,
                    'sample_number' => $sampleRow['sample_number'],
                    'sample_value' => $sampleRow['sample_value'],
                    'sample_result' => $sampleRow['sample_result'],
                    'created_at'     => now(),
                    'updated_at'     => now(),
                    'updated_by'     => Auth::id(),                    
                ]);
            }
        }
    }

    public function startRow(): int
    {
        return 2; // Skip header row
    }
}
